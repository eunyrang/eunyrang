# rProgressbar
a light wet highly customize able  jQuery plugin for progress bar 

#load rprogressbar css
 #<link rel="stylesheet" href="assets/css/jquery.rprogessbar.min.css">
  
#load rprogressbar js
<pre>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
 <script src="assets/js/jQuery.rProgressbar.min.js"></script>
</pre>
    
#if you don't have jquery script than use like below order    
<pre>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-migrate/3.1.0/jquery-migrate.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>
 <script src="assets/js/jQuery.rProgressbar.min.js"></script>
</pre>
#activate rProgressbar
<pre>
 $('.className').rProgressbar({
    percentage: 95,,
    fillBackgroundColor: '#f1c40f',
    backgroundColor: '#e67e22'
});
</pre>
#available options
<pre>
percentage: null,
ShowProgressCount: true,
duration: 1000,
fillBackgroundColor: '#ed1c24',
backgroundColor: '#EEEEEE',
borderRadius: '0px',
height: '10px',
width: '100%'
</pre>
#documentation link
